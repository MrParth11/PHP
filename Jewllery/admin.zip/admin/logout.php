<?php
include_once ("../connection.php");
session_start();
unset($_SESSION["admin_name"]);
unset($_SESSION["admin_pwd"]);
?>
<script>
    window.location = "../index.php";
</script>