<?php
include_once ("../connection.php");
include_once ('header.php');
$_SESSION['title'] = "Manage About";
include_once ('session.php');
?>

<div class="container-fluid">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">
            <?php echo $_SESSION['title']; ?>
        </h1>
    </div>

    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <a href="add_about.php" class="btn btn-sm btn-primary shadow-sm"><i
                        class="fas fa-plus-circle fa-sm text-white-50"></i> Add about details</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Image1</th>
                                <th>Image2</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Edit</th>
                                <th>Delete</th>
                                <th>Activation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "select * from about";
                            $result = mysqli_query($con, $sql);
                            while ($f = mysqli_fetch_array($result)) { ?>
                                <tr>
                                    <td>
                                        <p>
                                            <?php echo $f[0] ?>
                                        </p>
                                    </td>
                                    <td>
                                        <img src="images/about/<?php echo $f[3]; ?>">
                                    </td>
                                    <td>
                                        <img src="images/about/<?php echo $f[4] ?>">
                                    </td>
                                    <td>
                                        <?php echo $f[1] ?>
                                    </td>
                                    <td>
                                        <?php echo $f[2] ?>
                                    </td>
                                    <td>
                                        <?php echo $f[5] ?>
                                    </td>
                                    <td> 
                                        <a href="manage_about_edit.php?id=<?php echo $f[0]; ?>" class="btn btn-sm btn-edit shadow-sm">Edit</a>
                                    </td>
                                    <td> 
                                        <a href="delete.php?id=<?php echo $f[0]; ?>"
                                        class="btn btn-sm btn-danger shadow-sm">Delete</a>
                                    </td>
                                    <?php if($f[5] == 'Inactive') {?>
                                    <td><a href="active.php?id=<?php echo $f[0]; ?>" class=" btn btn-sm btn-active shadow-sm"> Active</a></td>
                                    <?php } elseif($f[5] == 'Active'){ ?>
                                    <td><a href="inactive.php?id=<?php echo $f[0]; ?>" class=" btn btn-sm btn-inactive shadow-sm"> Inactive</a></td>
                                    <?php } else {?>
                                    <td><a href="active.php?id=<?php echo $f[0]; ?>" class=" btn btn-sm btn-reactive shadow-sm"> Reactive</a></td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<?php include_once ('footer.php'); ?>