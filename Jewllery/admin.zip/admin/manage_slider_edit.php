<?php
include_once ("../connection.php");
include_once ('header.php');
$id = $_REQUEST['id'];
$q2 = "select * from slider where id ='$id'";
$res = mysqli_query($con, $q2);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Edit slider details</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <?php
                while($r=mysqli_fetch_array($res)) {
                ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Title</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="title" class="form-control1" placeholder="Enter title" value="<?php echo $r[1] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label"
                            style="color:#1f2e88; font-size:1.2rem;">Description</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="desc" class="form-control1" placeholder="Enter description" value="<?php echo $r[2] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Image</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <img src="images/home_slider/<?php echo $r[3]; ?>" height="100px" width="150px">
                                <input type="file" name="img" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[3] ?>">
                                <input type="hidden" name="old_img" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[3] ?>">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="status" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[4] ?>"
                                    placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="slider_update" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['slider_update'])) {
    $title = @$_POST['title'];
    $desc = @$_POST['desc'];
    $img = @$_FILES['img']['name'];
    $old_img = $_POST['old_img'];
    $status = @$_POST['status'];

    $q = "update slider set title = '$title', description = '$desc', image = '$img', status = '$status' where id = '$id'";

    $q1= "update slider set title = '$title', description = '$desc', image = '$old_img', status = '$status' where id = '$id'";
    
    if (isset($_FILES['img']['name']) && $_FILES['img']['name'] != "") 
    {
        if (mysqli_query($con, $q)) 
        {
        move_uploaded_file($_FILES['img']['tmp_name'], "images/home_slider/" . $_FILES['img']['name']);
            ?>
                <script>alert('Slider Updatted Successfully');
                    window.location = "manage_slider.php";</script>
                <?php
        }
    }
    else
    {   if (mysqli_query($con, $q1)) 
        {
            ?>
                <script>alert('Slider Updatted Successfully');
                    window.location = "manage_slider.php";</script>
                <?php
        }
    }
}
?>