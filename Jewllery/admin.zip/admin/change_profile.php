<?php
include_once ("../connection.php");
include_once ('header.php');
include_once ('session.php');
$em = $_SESSION['admin_name'];
$q2 = "select * from admin where email ='$em'";
$res = mysqli_query($con, $q2);
$r=mysqli_fetch_array($res);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Change profile</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Name</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="name" class="form-control1" 
                                value="<?php echo $r[1]; ?>" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Email</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="email" class="form-control1" 
                                value="<?php echo $r[2] ?>" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Profile</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="file" name="img" class="form-control1" style="margin-top:0.6rem;">
                                <input type="hidden" name="old_img" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[4] ?>">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="change" class="btn btn-sm btn-primary shadow-sm" style="margin-left:0.8rem;">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['change'])) {
    $name = @$_POST['name'];
    $email = @$_POST['email'];
    $img = @$_FILES['img']['name'];
    $old_img = @$_POST['old_img'];

    $q = "update admin set name = '$name',email = '$email',profile = '$img' where email = '$em'";
    $q1 = "update admin set name = '$name',email = '$email',profile = '$old_img' where email = '$em'";

    if (isset($_FILES['img']['name']) && $_FILES['img']['name'] != "") 
    {
        if (mysqli_query($con, $q)) 
        {
            move_uploaded_file($_FILES['img']['tmp_name'], "../images/profile/" . $_FILES['img']['name']);
            ?>
            <script>alert('Profile Updatted Successfully');
                window.location = "dashboard.php";</script>
            <?php
        }
    }
    else
    {
        if (mysqli_query($con, $q1)) 
        {
            ?><script>alert('Profile Updatted Successfully');
                window.location = "dashboard.php";</script>
            <?php
        }
    }
}
?>