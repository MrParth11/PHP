<?php 
include_once("../connection.php");
include_once ('header.php');
include_once ('session.php');
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Add new product</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label"
                            style="color:#ff3368; font-size:1.2rem; margin-top:1rem;">Category  </label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <select name="category" class="form-control1">
                                    <option value="">Select categories</option>
                                    <?php
                                        $sql="select * from categories";
                                        $result=mysqli_query($con,$sql);
                                        while($f=mysqli_fetch_array($result))
                                        {?>
                                            <option value="<?php echo $f[1]; ?>" ><?php echo $f[1]; ?>
                                            </option>
                                    <?php } ?>
                                </select> 
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label"
                            style="color:#ff3368; font-size:1.2rem;">Name</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="name" class="form-control1"
                                    placeholder="Enter product name" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Description</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="desc" class="form-control1"
                                    placeholder="Enter description" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Price</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="number" name="price" class="form-control1" placeholder="Enter price" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Color</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="color" class="form-control1"
                                    placeholder="Enter color" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Product Image</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="file" name="img" class="form-control1"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Banner Image</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="file" name="bimg" class="form-control1"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="status" class="form-control1"
                                    style="margin-top:0.6rem;" placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Add" name="product_add" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['product_add'])) {
    $cat = @$_POST['category'];
    $name = @$_POST['name'];
    $desc = @$_POST['desc'];
    $price = @$_POST['price'];
    $color = @$_POST['color'];
    $img = @$_FILES['img']['name'];
    $bimg = @$_FILES['bimg']['name'];
    $status = @$_POST['status'];

    $q = "insert into product values('','$cat','$name','$desc','$price','$color','$img','$bimg','','','$status')";
    if(mysqli_query($con, $q)) 
    {
        if ($_FILES['img']['name'] == "") 
        { ?>
            <script>alert('Select image for product');</script>
            <?php
        } 
        else 
        {
                move_uploaded_file($_FILES['img']['tmp_name'], "images/products/" . $_FILES['img']['name']);
                move_uploaded_file($_FILES['bimg']['tmp_name'], "images/products/" . "banner_
                img_" . $_FILES['bimg']['name']);
            ?>
            <script>alert('Successfully product Added');
            window.location = "manage_products.php";</script> 
            <?php
        }
    }
    else
    {
        ?><script>alert("something wrong");</script><?php
    }
}
?>