<?php
include_once ("../connection.php");
include_once ('header.php');
$id = $_REQUEST['id'];
$q2 = "select * from about where id ='$id'";
$res = mysqli_query($con, $q2);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Edit about details</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <?php
                while($r=mysqli_fetch_array($res)) {
                ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Title 1</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="title1" class="form-control1" placeholder="Enter title " value="<?php echo $r[1] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Description
                            1</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="desc1" class="form-control1" placeholder="Enter description" value="<?php echo $r[2] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Image 1</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <img src="images/about/<?php echo $r[3]; ?>" height="150px" width="200px">
                                <input type="file" name="img1" class="form-control1" style="margin-top:0.6rem;">
                                <input type="hidden" name="old_img1" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[3] ?>">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Image 2</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <img src="images/about/<?php echo $r[4]; ?>" height="150px" width="200px">
                                <input type="file" name="img2" class="form-control1" style="margin-top:0.6rem;">
                                <input type="hidden" name="old_img2" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[4] ?>">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="status" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[5] ?>"
                                    placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="about_update" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['about_update'])) {
    $title1 = @$_POST['title1'];
    $desc1 = @$_POST['desc1'];
    $img1 = @$_FILES['img1']['name'];
    $img2 = @$_FILES['img2']['name'];
    $old_img1 = @$_POST['old_img1'];
    $old_img2 = @$_POST['old_img2'];
    $status = @$_POST['status'];

    $q = "update about set title = '$title1', description = '$desc1',image1 = '$img1', image2 = '$img2', status = '$status' where id = '$id'";

    $q1 = "update about set title = '$title1', description = '$desc1',image1 = '$old_img1', image2 = '$img2', status = '$status' where id = '$id'";

    $q2 = "update about set title = '$title1', description = '$desc1',image1 = '$img1', image2 = '$old_img2', status = '$status' where id = '$id'";

    $q3 = "update about set title = '$title1', description = '$desc1',image1 = '$old_img1', image2 = '$old_img2', status = '$status' where id = '$id'";

    if(isset($_FILES['img1']['name']) && $_FILES['img1']['name'] != "" && isset($_FILES['img2']['name']) && $_FILES['img2']['name'] != "")
    {
        if (mysqli_query($con, $q)) 
        {
            move_uploaded_file($_FILES['img1']['tmp_name'], "images/about/" . $_FILES['img1']['name']);
            move_uploaded_file($_FILES['img2']['tmp_name'], "images/about/" . $_FILES['img2']['name']);
            ?>
                <script>alert('About details updatted successfully');
                    window.location = "manage_about.php";</script>
                <?php
        }
    }
    else if (isset($_FILES['img1']['name']) && $_FILES['img1']['name'] != "") 
    {
        if (mysqli_query($con, $q2)) 
        {
                move_uploaded_file($_FILES['img1']['tmp_name'], "images/about/" . $_FILES['img1']['name']);
                ?>
                <script>alert('About details updatted successfully');
                    window.location = "manage_about.php";</script>
                <?php
        }
    }
    else if (isset($_FILES['img2']['name']) && $_FILES['img2']['name'] != "") 
    {
        if (mysqli_query($con, $q1)) {
            move_uploaded_file($_FILES['img2']['tmp_name'], "images/about/" . $_FILES['img2']['name']);
            ?>
                    <script>alert('About details updatted successfully');
                        window.location = "manage_about.php";</script>
                <?php
        }
    } else {
        if (mysqli_query($con, $q3)) 
        {
            ?>
                <script>alert('About details updatted successfully');
                    window.location = "manage_about.php";</script>
                <?php
        }
    }
}
?>