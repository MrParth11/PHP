<?php
include_once ("../connection.php");
include_once ('header.php');
include_once ('session.php');
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Add New contact detail</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Title</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="title" class="form-control1" placeholder="Enter title"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Address</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="add" class="form-control1" placeholder="Enter address"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Email</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="email" name="email" class="form-control1" placeholder="Enter email"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Phone</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="number" name="number" class="form-control1" style="margin-top:0.6rem;"
                                    placeholder="Enter number">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Add" name="contact_add" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['contact_add'])) {
    $title = @$_POST['title'];
    $add = @$_POST['add'];
    $email = @$_POST['email'];
    $number = @$_POST['number'];

    $q = "insert into contact values('','$title','$add','$email','$number','','')";
    if (mysqli_query($con, $q)) {
        ?>
        <script>alert('Successfully Contact Details Added');
            window.location = "manage_contact.php";</script>
        <?php
    } else {
        ?>
        <script>alert("something wrong");</script>
        <?php
    }
}
?>