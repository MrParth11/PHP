<?php
include_once ("../connection.php");
session_start();
$em = $_REQUEST['em'];
$id = $_REQUEST['id'];
if (isset ($_SESSION['title'])) 
{
    if ($_SESSION['title'] == "Manage User") {
        $q = "update users set status='Active' where email='$em'";
        if (mysqli_query($con, $q)) {
            ?>
            <script>alert('User Activate Successfully');
                window.location = "manage_user.php";
            </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Products") {
        $q = "update product set status='Active' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Product Activate Successfully');
                    window.location = "manage_products.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage About") {
        $q = "update about set status='Active' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                        <script>alert('About Details Activate Successfully');
                            window.location = "manage_about.php";
                        </script>
                    <?php
        }
    }
    if ($_SESSION['title'] == "Manage Slider") {
        $q = "update slider set status='Active' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Slider Details Activate Successfully');
                    window.location = "manage_slider.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Categories") {
        $q = "update categories set status='Active' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Category Activate Successfully');
                    window.location = "manage_categories.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Reviews") {
        $q = "update review set status='Active' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Review Activate Successfully');
                    window.location = "manage_reviews.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Contact") {
        $q = "update contact set status='Complete' where email='$em'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Contact status updatted Successfully');
                    window.location = "manage_contact.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Inquires") {
        $q = "update inquiry set status='Complete' where email='$em'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Inquiry status updatted Successfully');
                    window.location = "manage_inquires.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Service") {
        $q = "update service set status='Active' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                        <script>alert('Service Activate Successfully');
                            window.location = "manage_services.php";
                        </script>
                    <?php
        }
    }
}
