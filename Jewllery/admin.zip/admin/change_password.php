<?php
include_once ("../connection.php");
include_once ('header.php');
include_once ('session.php');
$em = $_SESSION['admin_name'];
$q2 = "select * from admin where email ='$em'";
$res = mysqli_query($con, $q2);
$r=mysqli_fetch_array($res);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Change Password</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Old password</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="old_pwd" class="form-control1" style="margin-top:0.6rem;" placeholder="Enter old password" >
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">New password</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="password" name="new_pwd" class="form-control1"  style="margin-top:0.6rem;" placeholder="Enter new password">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Confirm Password</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="password" name="con_pwd" class="form-control1" style="margin-top:0.6rem;" placeholder="Enter confirm password">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="change" class="btn btn-sm btn-primary shadow-sm" style="margin-left:0.8rem;">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['change'])) {
    $old_pwd = @$_POST['old_pwd'];
    $new_pwd = @$_POST['new_pwd'];
    $con_pwd = @$_POST['con_pwd'];

    $q = "update admin set password = '$new_pwd' where email = '$em'";

    if($old_pwd == $_SESSION['admin_pwd'])
    {
        if($new_pwd == $con_pwd)
        {
            if (mysqli_query($con, $q)) 
            {
                ?>
                <script>alert('Password Updatted Successfully');
                    window.location = "dashboard.php";</script>
                <?php
            }
        }
        else
        {
            ?><script>alert("New and confirm password does not match");</script><?php
        }
    }
    else
    {
        ?><script>alert("Old password is incorrect");</script><?php 
    }
}
?>