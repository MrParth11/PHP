</div>
<footer class="sticky-footer">
    <div class="container my-auto">
        <div class="copyright text-center">
            <span>Copyright By Kunjal Thakker &copy; 2024 All Rights Reserved !</span>
        </div>
    </div>
</footer>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>

</body>

</html>