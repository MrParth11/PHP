<?php
include_once ("../connection.php");
include_once ('header.php');
$id = $_REQUEST['id'];
$q2 = "select * from contact where id ='$id'";
$res = mysqli_query($con, $q2);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Edit contact detail</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <?php
                while($r=mysqli_fetch_array($res)) {
                ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Title</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="title" class="form-control1" placeholder="Enter title" value="<?php echo $r[1] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Address</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="add" class="form-control1" placeholder="Enter address" value="<?php echo $r[2] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Email</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="email" name="email" class="form-control1" placeholder="Enter email" value="<?php echo $r[3] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Phone</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="number" name="number" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[4] ?>"
                                    placeholder="Enter number">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="contact_up" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['contact_up'])) {
    $title = @$_POST['title'];
    $add = @$_POST['add'];
    $email = @$_POST['email'];
    $number = @$_POST['number'];

    $q = "update contact set title = '$title',address = '$add',email = '$email',phone = '$number' where id = '$id'";
    if (mysqli_query($con, $q)) 
    {
        ?>
        <script>alert('Contact Details Updatted Successfully');
            window.location = "manage_contact.php";</script>
        <?php
    } else {
        ?>
        <script>alert("something wrong");</script>
        <?php
    }
}
?>