<?php
include_once ("../connection.php");
include_once ('header.php');
$id = $_REQUEST['id'];
$q2 = "select * from product where id ='$id'";
$res = mysqli_query($con, $q2);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Edit product</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <?php
                while($r=mysqli_fetch_array($res)) {
                ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label"
                            style="color:#1f2e88; font-size:1.2rem; margin-top:1rem;">Category </label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <select name="category" class="form-control1">
                                    <option value="">Select categories</option>
                                    <?php
                                    $sql = "select * from categories";
                                    $result = mysqli_query($con, $sql);
                                    while ($f = mysqli_fetch_array($result)) { ?>
                                        <option value="<?php echo $f[1]; ?>" <?php if($f[1] == $r[1]) { ?> selected <?php } ?>>
                                            <?php echo $f[1]; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Name</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="name" class="form-control1" placeholder="Enter product name" value="<?php echo $r[2] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label"
                            style="color:#1f2e88; font-size:1.2rem;">Description</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="desc" class="form-control1" placeholder="Enter description" value="<?php echo $r[3] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Price</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="number" name="price" class="form-control1" placeholder="Enter price" value="<?php echo $r[4] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Color</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="color" class="form-control1" placeholder="Enter color" value="<?php echo $r[5] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Product
                            Image</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <img src="images/products/<?php echo $r[6] ?>" height="150px" width="200px">
                                <input type="file" name="img" class="form-control1" style="margin-top:0.6rem;">
                                <input type="hidden" name="old_img" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[6] ?>">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Banner
                            Image</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="file" name="bimg" class="form-control1" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="status" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[10] ?>"
                                    placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="product_update" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['product_update'])) {
    $cat = @$_POST['category'];
    $name = @$_POST['name'];
    $desc = @$_POST['desc'];
    $price = @$_POST['price'];
    $color = @$_POST['color'];
    $old_img = @$_POST['old_img'];
    $img = @$_FILES['img']['name'];
    $bimg = @$_FILES['bimg']['name'];
    $status = @$_POST['status'];

    $q = "update product set category = '$cat', name = '$name', description = '$desc',price = '$price',color = '$color', image = '$img', banner_image = '$bimg' , status = '$status' where id = '$id'";

    $q1 = "update product set category = '$cat', name = '$name', description = '$desc',price = '$price',color = '$color', image = '$old_img', banner_image = '$bimg' , status = '$status' where id = '$id'";
    
    if (isset($_FILES['img']['name']) && $_FILES['img']['name'] != "") 
    {
        if (mysqli_query($con, $q)) 
        {
                move_uploaded_file($_FILES['img']['tmp_name'], "images/products/" . $_FILES['img']['name']);
                ?>
                <script>alert('Product updated successfully');
                    window.location = "manage_products.php";</script>
                <?php
        }
    } else {
        if (mysqli_query($con, $q1)) {
            ?>
            <script>alert('Product updated successfully');
                    window.location = "manage_products.php";</script>
                <?php
        }
    }
}
?>