<?php
include_once ("../connection.php");
include_once ('header.php');
include_once('session.php');
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Add slider details</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Title</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="title" class="form-control1" placeholder="Enter title "
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Description</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="desc" class="form-control1" placeholder="Enter description"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Image</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="file" name="img" class="form-control1" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="status" class="form-control1" style="margin-top:0.6rem;"
                                    placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Add" name="slider_add" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['slider_add'])) {
    $title = @$_POST['title'];
    $desc = @$_POST['desc'];
    $img = @$_FILES['img']['name'];
    $status = @$_POST['status'];

    $q = "insert into slider values('','$title','$desc','$img','$status','','')";
    if (mysqli_query($con, $q)) 
    {
        if ($_FILES['img']['name'] == "") 
        { ?>
            <script>alert('Select image for slider');</script>
            <?php
        } else {
            move_uploaded_file($_FILES['img']['tmp_name'], "images/home_slider/" . $_FILES['img']['name']);
            ?>
            <script>alert('Successfully slider Added');
                window.location = "manage_slider.php";</script>
            <?php
        }
    } else {
        ?>
        <script>alert("something wrong");</script>
        <?php
    }
}
?>