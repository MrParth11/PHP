<?php
include_once ("../connection.php");
session_start();
$em = $_REQUEST['em'];
$id = $_REQUEST['id'];
if (isset ($_SESSION['title'])) 
{
    if ($_SESSION['title'] == "Manage User") {
        $q = "update users set status='Inactive' where email='$em'";
        if (mysqli_query($con, $q)) {
            ?>
            <script>alert('User Inactivate Successfully');
                window.location = "manage_user.php";
            </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Products") {
        $q = "update product set status='Inactive' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Product Inactivate Successfully');
                    window.location = "manage_products.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage About") {
        $q = "update about set status='Inactive' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('About Details Inactivate Successfully');
                    window.location = "manage_about.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Slider") {
        $q = "update slider set status='Inactive' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Slider Details Inactivate Successfully');
                    window.location = "manage_slider.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Categories") {
        $q = "update categories set status='Inactive' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Category Inactivate Successfully');
                    window.location = "manage_categories.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Reviews") {
        $q = "update review set status='Inactive' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Review Inactivate Successfully');
                    window.location = "manage_reviews.php";
                </script>
            <?php
        }
    }
    if ($_SESSION['title'] == "Manage Service") {
        $q = "update service set status='Inactive' where id='$id'";
        if (mysqli_query($con, $q)) {
            ?>
                <script>alert('Service Inactivate Successfully');
                    window.location = "manage_services.php";
                </script>
            <?php
        }
    }
}
