<?php
include_once ("../connection.php");
include_once ('header.php');
$id = $_REQUEST['id'];
$q2 = "select * from service where id ='$id'";
$res = mysqli_query($con, $q2);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Edit Service</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <?php
                while($r=mysqli_fetch_array($res)) {
                ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Name</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="name" class="form-control1" placeholder="Enter name" value="<?php echo $r[1] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Message</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="msg" class="form-control1" placeholder="Enter message" value="<?php echo $r[2] ?>"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Icon</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="icon" class="form-control1" 
                                placeholder="Enter icon code" value="<?php echo $r[3] ?>" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#1f2e88; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" name="status" class="form-control1" style="margin-top:0.6rem;" value="<?php echo $r[4] ?>"
                                    placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Update" name="ser_up" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['ser_up'])) {
    $name = @$_POST['name'];
    $msg = @$_POST['msg'];
    $icon = @$_POST['icon'];
    $status = @$_POST['status'];

    $q = "update service set name = '$name',message = '$msg',icon = '$icon',status = '$status' where id = '$id'";
    if (mysqli_query($con, $q)) 
    {
            ?>
            <script>alert('Service updatted successfully');
                window.location = "manage_services.php";</script>
            <?php
    } else {
        ?>
        <script>alert("something wrong");</script>
        <?php
    }
}
?>