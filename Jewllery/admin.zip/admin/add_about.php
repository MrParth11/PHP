<?php 
include_once("../connection.php");
include_once ('header.php');
include_once ('session.php');
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Add about details</h1>
    </div>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label"
                            style="color:#ff3368; font-size:1.2rem;">Title</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="title1" class="form-control1"
                                    placeholder="Enter title " style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Description</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="desc1" class="form-control1"
                                    placeholder="Enter description" style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Image 1</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="file" name="img1" class="form-control1"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Image 2</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="file" name="img2" class="form-control1"
                                    style="margin-top:0.6rem;">
                            </div>
                        </div>
                    </div><br>
                    <div class="form-group">
                        <label class="col-md-2 control-label" style="color:#ff3368; font-size:1.2rem;">Status</label>
                        <div class="col-md-12">
                            <div class="input-group"> 
                                <input type="text" name="status" class="form-control1"
                                    style="margin-top:0.6rem;" placeholder="Enter status">
                            </div>
                        </div>
                    </div><br>
                    <input type="submit" value="Add" name="about_add" class="btn btn-sm btn-primary shadow-sm"
                        style="margin-left:0.8rem;">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once ('footer.php');

if (isset ($_POST['about_add'])) {
    $title1 = @$_POST['title1'];
    $desc1 = @$_POST['desc1'];
    $img1 = @$_FILES['img1']['name'];
    $img2 = @$_FILES['img2']['name'];
    $status = @$_POST['status'];

    $q = "insert into about values('','$title1','$desc1','$img1','$img2','$status','','')";
    if(mysqli_query($con, $q)) 
    {
        if ($_FILES['img1']['name'] == "" || $_FILES['img2']['name'] == "") 
        { ?>
            <script>alert('Select image for product');</script>
            <?php
        } 
        else 
        {
            move_uploaded_file($_FILES['img1']['tmp_name'], "images/about/" . $_FILES['img1']['name']);
            move_uploaded_file($_FILES['img2']['tmp_name'], "images/about/" . $_FILES['img2']['name']);
            ?>
            <script>alert('Successfully product Added');
            window.location = "manage_about.php";</script> 
            <?php
        }
    }
    else
    {
        ?><script>alert("something wrong");</script><?php
    }
}
?>